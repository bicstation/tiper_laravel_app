<?php
/**
 * Tiper Blog Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Tiper_Blog_Theme
 */

if ( ! function_exists( 'tiper_blog_theme_setup' ) ) :
    /**
     * Sets up theme defaults and registers support for various WordPress features.
     *
     * Note that this function is hooked into the after_setup_theme hook, which
     * runs before the init hook. The init hook is too late for some features, such
     * as indicating support for post thumbnails.
     */
    function tiper_blog_theme_setup() {
        /*
         * Make theme available for translation.
         * Translations can be filed in the /languages/ directory.
         * If you're building a theme based on Tiper Blog Theme, use a find and replace
         * to change 'tiper-blog-theme' to the name of your theme in all the template files.
         */
        load_theme_textdomain( 'tiper-blog-theme', get_template_directory() . '/languages' );

        // Add default posts and comments RSS feed links to head.
        add_theme_support( 'automatic-feed-links' );

        /*
         * Let WordPress manage the document title.
         * By adding theme support, we declare that this theme does not use a
         * hard-coded <title> tag in the document head, and expect WordPress to
         * provide it for us.
         */
        add_theme_support( 'title-tag' );

        /*
         * Enable support for Post Thumbnails on posts and pages.
         *
         * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
         */
        add_theme_support( 'post-thumbnails' );

        // This theme uses wp_nav_menu() in one location.
        register_nav_menus( array(
            'primary' => esc_html__( 'Primary menu', 'tiper-blog-theme' ),
            'sidebar-desktop' => esc_html__( 'Desktop Sidebar', 'tiper-blog-theme' ), // サイドバーメニューを追加
            'sidebar-mobile' => esc_html__( 'Mobile Sidebar', 'tiper-blog-theme' ),   // モバイルサイドバーメニューを追加
            'footer-related' => esc_html__( 'Footer Related Domains', 'tiper-blog-theme' ), // フッター関連ドメインメニュー
            'footer-general' => esc_html__( 'Footer General Links', 'tiper-blog-theme' ),   // フッター一般リンクメニュー
        ) );

        /*
         * Switch default core markup for search form, comment form, and comments
         * to output valid HTML5.
         */
        add_theme_support( 'html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'script',
            'style',
        ) );

        // Add theme support for selective refresh for widgets in Customizer.
        add_theme_support( 'customize-selective-refresh-widgets' );

        /**
         * Add support for core custom logo.
         *
         * @link https://developer.wordpress.org/themes/functionality/custom-logo/
         */
        add_theme_support( 'custom-logo', array(
            'height'      => 250,
            'width'       => 250,
            'flex-width'  => true,
            'flex-height' => true,
        ) );
    }
endif;
add_action( 'after_setup_theme', 'tiper_blog_theme_setup' );

/**
 * Enqueue scripts and styles.
 */
function tiper_blog_theme_scripts() {
    // Theme stylesheet (style.css is always loaded by default but adding it here for clarity if you modify it)
    wp_enqueue_style( 'tiper-blog-theme-style', get_stylesheet_uri(), array(), '1.0.0' );

    // External CSS (CDNs)
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css', array(), '6.0.0-beta3' );
    wp_enqueue_style( 'bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css', array(), '5.3.3' );

    // Custom CSS from Laravel build (Copy these files to tiper-blog-theme/css/)
    wp_enqueue_style( 'tiper-style-v2', get_template_directory_uri() . '/css/style_v2.css', array(), '1.0.0' );
    wp_enqueue_style( 'tiper-app-bhcmqxf2-css', get_template_directory_uri() . '/css/app-BhcmQXf2.css', array(), '1.0.0' );

    // External JavaScript (CDNs)
    // Bootstrap Bundle includes Popper.js
    wp_enqueue_script( 'bootstrap-bundle-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js', array(), '5.3.3', true );

    // Custom JavaScript from Laravel build (Copy this file to tiper-blog-theme/js/)
    wp_enqueue_script( 'tiper-app-ak4yfpff-js', get_template_directory_uri() . '/js/app-ak4YfpFF.js', array('bootstrap-bundle-js'), '1.0.0', true );

    // Custom inline JavaScript (Copy this code into a new file: tiper-blog-theme/js/custom-sidebar.js)
    wp_enqueue_script( 'tiper-custom-sidebar-js', get_template_directory_uri() . '/js/custom-sidebar.js', array('bootstrap-bundle-js'), '1.0.0', true );

}
add_action( 'wp_enqueue_scripts', 'tiper_blog_theme_scripts' );

/**
 * Replace Laravel-specific image paths with WordPress theme paths.
 * This is a helper function to avoid repeating get_template_directory_uri().
 */
function tiper_blog_theme_img_path( $path ) {
    return esc_url( get_template_directory_uri() . '/img/' . ltrim( $path, '/' ) );
}

?>